using UnityEngine;

public class MethodsPractice : MonoBehaviour
{
    [SerializeField] int a, b, c;

    void OnValidate()
    {
        Debug.Log(ClampValue(a,b,c));
    }

    void WriteMultiplicationTable(int baseNumber)
    {
        for (int i = 1; i <= baseNumber; i++)
            for (int j = i; j <= baseNumber; j++)
                Debug.Log($"{j} * {i} = {i * j}");
    }

    int Minimum(int num1, int num2)
    {
        return num1 < num2 ? num1 : num2;
    }

    

    float PowerValue(float number, float power)
    {
        for(int i = 1; i <= power; i++) 
            number *= number;
        return number;
    }
    float AbsoluteValue(float number)
    {
        return number > 0f ? number : -number;
    }

    int SignValue(float number)
    {
        return number > 0 ? 1 : -1;
    }

    float RoundValue(float number)
    {
        return AbsoluteValue(number) - (int)AbsoluteValue(number) >= 0.5f ? (int)number + SignValue(number) : (int)number;
    }

    float ClampValue(float number, float floor, float ceiling)
    {
        return number < floor ? floor : (number > ceiling ? ceiling : number);
    }
}
