using UnityEngine;

public class VectorPractice : MonoBehaviour
{
    private void Start()
    {
        Vector2 myVector2D = new Vector2(2, 3);
        Vector3 myVector3D = new Vector3(2, 3, 5);

        Debug.Log(myVector2D.x);
    }
}
